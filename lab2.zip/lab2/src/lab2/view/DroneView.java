package lab2.view;

import java.util.List;
import java.util.Scanner;

import lab2.model.Drone;
import lab2.model.DroneDatabase;
import lab2.model.DroneType;

/**
 * Handles input and output in the console.
 */
public class DroneView {
	/**
	 * 	Creates the console view.
	 */
	public DroneView(){
	}

    private Scanner input =
            new Scanner(System.in);

    /**
     * Displays information about the drone database.
     * 
     * @param database drone database to display
     */
    public void showDatabase(
            DroneDatabase database) {

        System.out.println(
                "Database: "
                        + database.size()
                        + " drones");

        for (DroneType type :
                DroneType.values()) {

            System.out.println(
                    type
                            + ": "
                            + database.count(type));
        }
    }

    /**
     * Reads information about a new drone.
     * 
     * @return the created drone
     */
    public Drone readDrone() {

        System.out.println(
                "\nADD NEW DRONE");

        System.out.print("Name: ");

        String name =
                input.nextLine();

        String[] names = {
                "Cruise speed",
                "Maximum speed",
                "Fuel range",
                "Control range",
                "Flight time",
                "Drone cost",
                "Preparation cost",
                "Reusable (1/0)",
                "Normal load",
                "Maximum load",
                "Maximum altitude",
                "Preparation time"
        };

        double[] values =
                new double[12];

        for (int i = 0;
             i < values.length;
             i++) {

            System.out.print(
                    names[i] + ": ");

            values[i] =
                    Double.parseDouble(
                            input.nextLine());
        }

        return new Drone(
                name,
                null,
                values);
    }

    /**
     * Displays information about a drone.
     * 
     * @param drone drone to display
     */
    public void showDrone(
            Drone drone) {

        DroneType[] priorities =
                drone.getPriorities();

        System.out.println(
                "Drone: "
                        + drone.getName());

        System.out.println(
                "Priorities: "
                        + priorities[0]
                        + ", "
                        + priorities[1]
                        + ", "
                        + priorities[2]);

        System.out.println(
                "Range at maximum speed/load: "
                        + drone.rangeAtMaximum());

        System.out.println(
                "Time at maximum speed/load: "
                        + drone.timeAtMaximum());

        System.out.println(
                "Technical cost: "
                        + drone.technicalCost());
    }

    /**
     * Displays the simulation results.
     * 
     * @param lines simulation results lines
     */
    public void showSimulation(
            List<String> lines) {

        System.out.println(
                "\nSIMULATION");

        for (String line : lines) {
            System.out.println(line);
        }
    }

    /**
     * Closes the input scanner.
     */
    public void close() {
        input.close();
    }
}