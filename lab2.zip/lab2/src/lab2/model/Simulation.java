package lab2.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Simulates targets, drones and base protection.
 */
public class Simulation {

    private DroneDatabase database;

    private Random random =
            new Random();

    private int baseHealth = 100;

    private boolean scoutActive = true;
    private int scoutLife = 3;
    private int scoutRestart = 0;

    private List<Target> targets =
            new ArrayList<Target>();

    /**
     * Creates a new simulation.
     * 
     * @param database drone database used in the simulation
     */
    public Simulation(
            DroneDatabase database) {

        this.database = database;
    }

    /**
     * Runs the simulation for the specified number of steps.
     * 
     * @param steps number of simulation steps
     * @return simulation results 
     */
    public List<String> run(int steps) {

        List<String> log =
                new ArrayList<String>();

        for (int step = 1;
             step <= steps;
             step++) {

            log.add("\nSTEP " + step);

            List<Target> newTargets =
                    createTargets();

            targets.addAll(newTargets);

            log.add(
                    "New targets: "
                            + newTargets.size());

            for (Target target : targets) {
                target.move();
            }

            updateScout(log);

            if (scoutActive) {
                processTargets(log);
            } else {
                log.add(
                        "Scout information is outdated.");
            }

            attackBase(log);

            targets.removeIf(
                    target -> !target.isActive());

            log.add(
                    "Base health: "
                            + baseHealth);

            if (baseHealth <= 0) {

                log.add(
                        "The drone base was destroyed.");

                break;
            }
        }

        return log;
    }

    private void updateScout(
            List<String> log) {

        if (scoutActive) {

            scoutLife--;

            if (scoutLife == 0) {

                scoutActive = false;
                scoutRestart = 2;

                log.add(
                        "Scout was destroyed. "
                        + "New scout is starting.");
            }

        } else {

            scoutRestart--;

            if (scoutRestart == 0) {

                scoutActive = true;

                scoutLife =
                        3 + random.nextInt(3);

                log.add(
                        "New scout started. "
                        + "Information is current.");
            }
        }
    }

    private List<Target> createTargets() {

        List<Target> result =
                new ArrayList<Target>();

        int count =
                5 + random.nextInt(26);

        TargetType[] types =
                TargetType.values();

        for (int i = 0;
             i < count;
             i++) {

            TargetType type =
                    types[random.nextInt(
                            types.length)];

            int x;
            int y;

            do {

                x = 1 + random.nextInt(100);

                /*
                 * Square root gives more
                 * targets far from the base.
                 */
                y = 10
                        + (int) (
                        Math.sqrt(
                                random.nextDouble())
                                * 91);

                if (y > 100) {
                    y = 100;
                }

            } while (
                    Math.hypot(
                            x - 50,
                            y - 1) < 10
            );

            boolean moving =
                    type == TargetType.TANK
                    || type == TargetType.SOLDIER
                    || type
                    == TargetType.STRIKE_DRONE;

            result.add(
                    new Target(
                            type,
                            x,
                            y,
                            moving));
        }

        return result;
    }

    private void processTargets(
            List<String> log) {

        for (Target target : targets) {

            if (!target.isActive()) {
                continue;
            }

            DroneType droneType =
                    selectDrone(
                            target.getType());

            int required =
                    requiredDrones(
                            target.getType());

            if (database.count(droneType)
                    >= required) {

                target.deactivate();

                log.add(
                        target.getType()
                                + " defeated by "
                                + required
                                + " "
                                + droneType);

            } else {

                log.add(
                        "Not enough drones for "
                                + target.getType());
            }
        }
    }

    private DroneType selectDrone(
            TargetType type) {

        switch (type) {

            case TANK:
            case CONCRETE_SHELTER:
                return DroneType.LONG_RANGE;

            case AIR_DEFENSE_PICKUP:
            case STRIKE_DRONE:
                return DroneType.INTERCEPTOR;

            case SOLDIER:
                return DroneType.SCOUT;

            default:
                return DroneType.MULTIPURPOSE;
        }
    }

    private int requiredDrones(
            TargetType type) {

        switch (type) {

            case TANK:
            case CONCRETE_SHELTER:
                return 3;

            case AIR_DEFENSE_PICKUP:
            case EARTH_SHELTER:
            case STRIKE_DRONE:
                return 2;

            default:
                return 1;
        }
    }

    private void attackBase(
            List<String> log) {

        for (Target target : targets) {

            if (!target.isActive()) {
                continue;
            }

            int damage =
                    target.attackDamage();

            if (damage > 0) {

                baseHealth =
                        Math.max(
                                0,
                                baseHealth - damage);

                log.add(
                        target.getType()
                                + " attacked the base: -"
                                + damage);
            }
        }
    }
}