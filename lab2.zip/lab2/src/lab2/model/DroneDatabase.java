package lab2.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Stores and manages the drone database.
 */
public class DroneDatabase {

    private List<Drone> drones =
            new ArrayList<Drone>();

    /**
     * Creates a database with the initial drones.
     */
    public DroneDatabase() {
        createInitialDatabase();
    }

    /**
     * Adds a drone to the database.
     * @param drone drone to add
     */
    public void addDrone(Drone drone) {
        drones.add(drone);
    }

    /**
     * Returns the number of drones
     * 
     * @return number of drones
     */
    public int size() {
        return drones.size();
    }

    /**
     * Counts drones of the specified type.
     * 
     * @param type drone type
     * @return number of drones type
     */
    public int count(DroneType type) {

        int result = 0;

        for (Drone drone : drones) {

            if (drone.getModelType() == type) {
                result++;
            }
        }

        return result;
    }

    private void createInitialDatabase() {

        for (int i = 1; i <= 10; i++) {

            addDrone(new Drone(
                    "Long-" + i,
                    DroneType.LONG_RANGE,
                    120, 180, 1200, 1000,
                    15, 50000, 2000, 1,
                    15, 25, 7000, 30));

            addDrone(new Drone(
                    "Interceptor-" + i,
                    DroneType.INTERCEPTOR,
                    250, 450, 400, 300,
                    4, 60000, 2500, 1,
                    10, 15, 6000, 10));

            addDrone(new Drone(
                    "Scout-" + i,
                    DroneType.SCOUT,
                    100, 150, 800, 700,
                    20, 40000, 1500, 1,
                    8, 12, 9000, 20));

            addDrone(new Drone(
                    "Cargo-" + i,
                    DroneType.CARGO,
                    90, 130, 600, 400,
                    8, 70000, 3000, 1,
                    80, 150, 4000, 40));

            addDrone(new Drone(
                    "Multi-" + i,
                    DroneType.MULTIPURPOSE,
                    150, 250, 700, 600,
                    10, 55000, 2200, 1,
                    35, 60, 6500, 25));
        }
    }
}