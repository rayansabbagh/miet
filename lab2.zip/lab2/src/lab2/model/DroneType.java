package lab2.model;

/**
 * Defines the available drone types.
 */
public enum DroneType {

    /** Long-range drone. */
    LONG_RANGE,

    /** Interceptor drone. */
    INTERCEPTOR,

    /** Scout drone. */
    SCOUT,

    /** Cargo drone. */
    CARGO,

    /** Multipurpose drone. */
    MULTIPURPOSE
}