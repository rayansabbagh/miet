package lab2.model;

import java.util.Arrays;
/**
 * Represents a drone with technical parameters and priorities.
 */
public class Drone {

    private String name;
    private DroneType modelType;

    private double[] parameters;

    private DroneType[] priorities;
/**
 * Creates a new drone.
 * @param name drone name
 * @param modelType drone model type
 * @param values drone technical values
 */
    public Drone(String name,
                 DroneType modelType,
                 double... values) {

    	super();
    	
        if (values.length != 12) {
            throw new IllegalArgumentException(
                    "Exactly 12 parameters are required");
        }

        this.name = name;
        this.modelType = modelType;
        this.parameters =
                Arrays.copyOf(values, values.length);

        classify();
    }

    private void classify() {

        DroneType[] types = DroneType.values();

        double[] score = {
                parameters[2] / 10
                        + parameters[3] / 10
                        + parameters[4] * 10,

                parameters[1] / 4
                        + parameters[0] / 10
                        + (parameters[11] < 20 ? 30 : 0),

                parameters[4] * 8
                        + parameters[3] / 12
                        + parameters[10] / 100,

                parameters[9] * 5
                        + parameters[2] / 20,

                parameters[0] / 10
                        + parameters[2] / 20
                        + parameters[4] * 5
                        + parameters[9]
        };

        for (int i = 0; i < score.length - 1; i++) {

            for (int j = i + 1;
                 j < score.length;
                 j++) {

                if (score[j] > score[i]) {

                    double temporaryScore = score[i];
                    score[i] = score[j];
                    score[j] = temporaryScore;

                    DroneType temporaryType = types[i];
                    types[i] = types[j];
                    types[j] = temporaryType;
                }
            }
        }

        priorities = Arrays.copyOf(types, 3);

        if (modelType == null) {
            modelType = priorities[0];
        }
    }

    /**
     * Returns the drone name.
     * 
     * @return drone name
     */
    public String getName() {
        return name;
    }

    /**
     *Returns the drone model type.
     * 
     * @return drone model type
     */
    public DroneType getModelType() {
        return modelType;
    }
/**
 * Returns the drone classification priorities.
 * 
 * @return array of priority types
 */
    public DroneType[] getPriorities() {
        return Arrays.copyOf(priorities, 3);
    }

    /**
     * Calculates the effective flight range.
     * 
     * @param speed flight speed
     * @param load payload flight
     * @return effective flight range
     */
    public double effectiveRange(
            double speed,
            double load) {

        double speedPart =
                part(
                        speed,
                        parameters[0],
                        parameters[1]);

        double loadPart =
                part(
                        load,
                        parameters[8],
                        parameters[9]);

        return parameters[2]
                * (1 - 0.40 * speedPart)
                * (1 - 0.30 * loadPart);
    }
/**
 * Calculates the effective flight time.
 * 
 * @param speed flight speed
 * @param load payload weight
 * @return effective flight time
 */
    public double effectiveTime(
            double speed,
            double load) {

        double speedPart =
                part(
                        speed,
                        parameters[0],
                        parameters[1]);

        double loadPart =
                part(
                        load,
                        parameters[8],
                        parameters[9]);

        return parameters[4]
                * (1 - 0.35 * speedPart)
                * (1 - 0.25 * loadPart);
    }

    private double part(
            double value,
            double normal,
            double maximum) {

        if (maximum <= normal) {
            return 0;
        }

        double result =
                (value - normal)
                        / (maximum - normal);

        return Math.max(
                0,
                Math.min(1, result));
    }

    /**
     * Calculates the range at maximum speed and payload.
     * 
     * @return range at maximum conditions
     */
    public double rangeAtMaximum() {

        return effectiveRange(
                parameters[1],
                parameters[9]);
    }

    /**
     * Calculates the range at maximum speed and payload.
     * 
     * @return flight time at maximum conditions
     */
    public double timeAtMaximum() {

        return effectiveTime(
                parameters[1],
                parameters[9]);
    }

    /**
     * Calculates the total technical cost of the drone.
     * 
     * @return total technical cost
     */
    public double technicalCost() {

        return parameters[0] * 10
                + parameters[1] * 15
                + parameters[2] * 5
                + parameters[3] * 4
                + parameters[4] * 100
                + parameters[5]
                + parameters[6]
                + (parameters[7] == 1 ? 5000 : 0)
                + parameters[8] * 50
                + parameters[9] * 80
                + parameters[10] * 2
                + parameters[11] * 20;
    }
}