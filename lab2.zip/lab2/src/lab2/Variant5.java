package lab2;

import lab2.controller.DroneController;
import lab2.model.DroneDatabase;
import lab2.view.DroneView;
/**
 * Starts the Variant 5 drone simulation program.
 */
public class Variant5 {
	/**
	 * Creates the main application.
	 */
	public Variant5() {
	}
/**
 * Main entry point of the program.
 * 
 * @param args command-line arguments
 */
    public static void main(
            String[] args) {

        DroneDatabase model =
                new DroneDatabase();

        DroneView view =
                new DroneView();

        DroneController controller =
                new DroneController(
                        model,
                        view);

        controller.start();
    }
}