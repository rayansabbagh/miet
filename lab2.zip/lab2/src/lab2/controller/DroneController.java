package lab2.controller;

import lab2.model.Drone;
import lab2.model.DroneDatabase;
import lab2.model.Simulation;
import lab2.view.DroneView;

/**
 * Controls communication between the model and the view.
 */
public class DroneController {

    private DroneDatabase model;
    private DroneView view;

    /**
     * Creates a drone controller.
     * 
     * @param model drone database model
     * @param view console view 
     */
    public DroneController(
            DroneDatabase model,
            DroneView view) {

        this.model = model;
        this.view = view;
    }

    /**
     * Starts the drone application.
     */
    public void start() {

        view.showDatabase(model);

        Drone drone =
                view.readDrone();

        model.addDrone(drone);

        view.showDrone(drone);

        Simulation simulation =
                new Simulation(model);

        view.showSimulation(
                simulation.run(8));

        view.close();
    }
}