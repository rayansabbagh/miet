package lab3.model;

import java.io.BufferedWriter;
import java.lang.reflect.Field;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import lab3.controller.ErrMsgLog;

/**
 * Measures collection operations and ArrayList capacity growth.
 */
public class CollectionExperiment {

    /**
     * Creates the collection experiment.
     */
    public CollectionExperiment() {
    }

    /**
     * Runs one collection experiment.
     * Object generation and logging are outside operation timers.
     *
     * @param arrayList whether to use ArrayList
     * @param size initial number of collection elements
     * @param messages centralized message handler
     * @return measured experiment result
     * @throws Exception if measurement or logging fails
     */
    public ExperimentResult run(
            boolean arrayList,
            int size,
            ErrMsgLog messages) throws Exception {

        if (size < 10 || size % 10 != 0) {

            throw new IllegalArgumentException(
                    "Size must be a positive multiple of 10");
        }

        String started =
                messages.now();

        String name =
                arrayList
                        ? "ArrayList"
                        : "LinkedList";

        RandomGenerator generator =
                new RandomGenerator(2026L + size);

        DroneDatabase[] input =
                new DroneDatabase[size];

        /*
         * Each main object contains three random drones.
         * Both collection types receive equivalent input data.
         */
        for (int i = 0; i < size; i++) {

            input[i] =
                    generator.generateDatabase(3);
        }

        ArrayList<DroneDatabase> array =
                arrayList
                        ? new ArrayList<DroneDatabase>(10)
                        : null;

        List<DroneDatabase> collection =
                arrayList
                        ? array
                        : new LinkedList<DroneDatabase>();

        Field elementData = null;

        if (arrayList) {

            elementData =
                    ArrayList.class.getDeclaredField(
                            "elementData");

            elementData.setAccessible(true);
        }

        long[] addTimes =
                new long[size];

        long[] removeTimes =
                new long[size / 10];

        int[] removedIndices =
                new int[size / 10];

        StringBuilder growthLog =
                new StringBuilder();

        long growthTotal = 0;
        long regularTotal = 0;

        int growthCount = 0;
        int regularCount = 0;

        for (int i = 0; i < size; i++) {

            int oldCapacity = 0;

            if (arrayList) {

                oldCapacity =
                        ((Object[]) elementData.get(array))
                                .length;
            }

            DroneDatabase value =
                    input[i];

            long start =
                    System.nanoTime();

            collection.add(value);

            long elapsed =
                    System.nanoTime() - start;

            addTimes[i] = elapsed;

            if (arrayList) {

                int actualCapacity =
                        ((Object[]) elementData.get(array))
                                .length;

                if (actualCapacity != oldCapacity) {

                    growthCount++;
                    growthTotal += elapsed;

                    int predictedCapacity =
                            oldCapacity * 3 / 2 + 1;

                    growthLog
                            .append("growth, index = ")
                            .append(i)
                            .append(", oldCapacity = ")
                            .append(oldCapacity)
                            .append(", predicted = ")
                            .append(predictedCapacity)
                            .append(", actual = ")
                            .append(actualCapacity)
                            .append(", formulaMatches = ")
                            .append(
                                    predictedCapacity
                                            == actualCapacity)
                            .append(", timeNs = ")
                            .append(elapsed)
                            .append('\n');

                } else {

                    regularCount++;
                    regularTotal += elapsed;
                }
            }
        }

        Random indices =
                new Random(5000L + size);

        for (int i = 0;
             i < removeTimes.length;
             i++) {

            int index =
                    indices.nextInt(
                            collection.size());

            removedIndices[i] = index;

            long start =
                    System.nanoTime();

            collection.remove(index);

            removeTimes[i] =
                    System.nanoTime() - start;
        }

        if (collection.size()
                != size - size / 10) {

            throw new IllegalStateException(
                    "Incorrect final collection size");
        }

        OperationStats addStats =
                new OperationStats(addTimes);

        OperationStats removeStats =
                new OperationStats(removeTimes);

        ExperimentResult result =
                new ExperimentResult(
                        name,
                        size,
                        addStats,
                        removeStats);

        try (BufferedWriter writer =
                     messages.open(
                             name + "_" + size + ".log")) {

            messages.line(
                    writer,
                    "Start program: " + started);

            messages.line(
                    writer,
                    name
                            + "<DroneDatabase>, N = "
                            + size
                            + ", unit = ns"
                            + ", indices = 0-based");

            for (int i = 0; i < size; i++) {

                messages.line(
                        writer,
                        "add, index = "
                                + i
                                + ", timeNs = "
                                + addTimes[i]);
            }

            messages.statistics(
                    writer,
                    "add",
                    addStats);

            for (int i = 0;
                 i < removeTimes.length;
                 i++) {

                messages.line(
                        writer,
                        "remove, index = "
                                + removedIndices[i]
                                + ", timeNs = "
                                + removeTimes[i]);
            }

            messages.statistics(
                    writer,
                    "remove",
                    removeStats);

            messages.line(
                    writer,
                    "allOperationsTotalTime = "
                            + (addStats.getTotal()
                            + removeStats.getTotal()));

            if (arrayList) {

                messages.line(
                        writer,
                        "Capacity check: "
                                + "(oldCapacity * 3) / 2 + 1");

                messages.line(
                        writer,
                        growthLog.toString());

                messages.line(
                        writer,
                        "growthCount = "
                                + growthCount);

                if (growthCount > 0) {

                    double growthMean =
                            (double) growthTotal
                                    / growthCount;

                    double regularMean =
                            (double) regularTotal
                                    / regularCount;

                    messages.line(
                            writer,
                            "growthMeanTime = "
                                    + growthMean);

                    messages.line(
                            writer,
                            "regularMeanTime = "
                                    + regularMean);

                    messages.line(
                            writer,
                            "growth/regular = "
                                    + (regularMean == 0
                                    ? Double.NaN
                                    : growthMean / regularMean));

                    messages.line(
                            writer,
                            growthMean > regularMean
                                    ? "Growth additions were slower on average."
                                    : "No average growth slowdown was observed.");

                } else {

                    messages.line(
                            writer,
                            "No growth: initial capacity = 10.");
                }

                messages.line(
                        writer,
                        "The assignment formula is historical."
                                + " Actual capacity depends on the JDK.");

                messages.line(
                        writer,
                        "Individual times include JVM and timer noise.");
            }

            messages.line(
                    writer,
                    "Finish program: "
                            + messages.now());
        }

        return result;
    }
}