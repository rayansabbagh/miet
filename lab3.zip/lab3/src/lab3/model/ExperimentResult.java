package lab3.model;

/**
 * Stores the results of one collection experiment.
 */
public class ExperimentResult {

    private String collectionName;
    private int size;

    private OperationStats addStats;
    private OperationStats removeStats;

    /**
     * Creates an experiment result.
     *
     * @param collectionName collection implementation name
     * @param size initial number of collection elements
     * @param addStats addition timing statistics
     * @param removeStats removal timing statistics
     */
    public ExperimentResult(
            String collectionName,
            int size,
            OperationStats addStats,
            OperationStats removeStats) {

        this.collectionName = collectionName;
        this.size = size;
        this.addStats = addStats;
        this.removeStats = removeStats;
    }

    /**
     * Returns the collection implementation name.
     *
     * @return collection name
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * Returns the initial collection size.
     *
     * @return initial number of elements
     */
    public int getSize() {
        return size;
    }

    /**
     * Returns addition timing statistics.
     *
     * @return addition statistics
     */
    public OperationStats getAddStats() {
        return addStats;
    }

    /**
     * Returns removal timing statistics.
     *
     * @return removal statistics
     */
    public OperationStats getRemoveStats() {
        return removeStats;
    }
}