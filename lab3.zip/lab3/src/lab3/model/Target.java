package lab3.model;

/**
 * Represents a target on the battlefield.
 */
public class Target {

    private TargetType type;
    private int x;
    private int y;

    private boolean moving;
    private boolean active = true;

    /**
     * Creates a new target.
     *
     * @param type target type
     * @param x horizontal coordinate
     * @param y vertical coordinate
     * @param moving whether the target can move
     */
    public Target(
            TargetType type,
            int x,
            int y,
            boolean moving) {

        this.type = type;
        this.x = x;
        this.y = y;
        this.moving = moving;
    }

    /**
     * Returns the target type.
     *
     * @return target type
     */
    public TargetType getType() {
        return type;
    }

    /**
     * Checks whether the target is active.
     *
     * @return true if the target is active
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Deactivates the target.
     */
    public void deactivate() {
        active = false;
    }

    /**
     * Calculates the distance to the base.
     *
     * @return distance to the base
     */
    public double distanceToBase() {

        return Math.hypot(
                x - 50,
                y - 1);
    }

    /**
     * Moves the target toward the base.
     */
    public void move() {

        if (!moving || !active) {
            return;
        }

        int cells =
                movementPerStep();

        for (int i = 0;
             i < cells;
             i++) {

            if (x < 50) {

                x++;

            } else if (x > 50) {

                x--;
            }

            if (y > 1) {
                y--;
            }
        }
    }

    /**
     * Returns the movement speed in cells per step.
     *
     * @return number of cells per step
     */
    private int movementPerStep() {

        switch (type) {

            case TANK:
                return 2;

            case SOLDIER:
                return 1;

            case STRIKE_DRONE:
                return 4;

            default:
                return 0;
        }
    }

    /**
     * Calculates the damage caused to the base.
     *
     * @return damage value
     */
    public int attackDamage() {

        double distance =
                distanceToBase();

        switch (type) {

            case TANK:

                return distance <= 5
                        ? 20 : 0;

            case SOLDIER:

                return distance <= Math.sqrt(2)
                        ? 1 : 0;

            case STRIKE_DRONE:

                return x == 50 && y == 1
                        ? 20 : 0;

            default:

                return 0;
        }
    }
}