package lab3.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates random drones, databases and targets.
 */
public class RandomGenerator {

    private Random random;

    /**
     * Creates a reproducible random generator.
     *
     * @param seed random seed
     */
    public RandomGenerator(
            long seed) {

        random = new Random(seed);
    }

    /**
     * Generates a drone with automatic classification.
     *
     * @param id drone identifier
     * @return generated drone
     */
    public Drone generateDrone(
            int id) {

        return generateDrone(id, null);
    }

    /**
     * Generates a drone with twelve technical parameters.
     *
     * @param id drone identifier
     * @param type model type,
     *             or null for automatic classification
     * @return generated drone
     */
    public Drone generateDrone(
            int id,
            DroneType type) {

        double cruiseSpeed =
                between(80, 250);

        double maximumSpeed =
                cruiseSpeed + between(20, 200);

        double normalLoad =
                between(5, 80);

        double maximumLoad =
                normalLoad + between(5, 80);

        return new Drone(
                "Random-" + id,
                type,
                cruiseSpeed,
                maximumSpeed,
                between(300, 1500),
                between(200, 1200),
                between(3, 24),
                between(30000, 90000),
                between(1000, 4000),
                random.nextBoolean() ? 1 : 0,
                normalLoad,
                maximumLoad,
                between(3000, 10000),
                between(5, 45));
    }

    /**
     * Generates a database containing random drones.
     *
     * @param count number of drones
     * @return generated database
     * @throws IllegalArgumentException if count is negative
     */
    public DroneDatabase generateDatabase(
            int count) {

        if (count < 0) {

            throw new IllegalArgumentException(
                    "Negative drone count");
        }

        DroneDatabase database =
                new DroneDatabase(false);

        for (int i = 1;
             i <= count;
             i++) {

            database.addDrone(
                    generateDrone(i));
        }

        return database;
    }

    /**
     * Generates a target of a random type.
     *
     * @return generated target
     */
    public Target generateTarget() {

        TargetType[] types =
                TargetType.values();

        TargetType type =
                types[random.nextInt(
                        types.length)];

        return generateTarget(type);
    }

    /**
     * Generates a target outside the initial base exclusion zone.
     *
     * @param type target type
     * @return generated target
     */
    public Target generateTarget(
            TargetType type) {

        int x;
        int y;

        do {

            x = 1 + random.nextInt(100);

            y = Math.min(
                    100,
                    10 + (int) (
                            Math.sqrt(
                                    random.nextDouble())
                                    * 91));

        } while (
                Math.hypot(
                        x - 50,
                        y - 1) < 10);

        boolean moving =
                type == TargetType.TANK
                        || type == TargetType.SOLDIER
                        || type
                        == TargetType.STRIKE_DRONE;

        return new Target(
                type,
                x,
                y,
                moving);
    }

    /**
     * Generates a list of random targets.
     *
     * @param count number of targets
     * @return generated targets
     * @throws IllegalArgumentException if count is negative
     */
    public List<Target> generateTargets(
            int count) {

        if (count < 0) {

            throw new IllegalArgumentException(
                    "Negative target count");
        }

        List<Target> targets =
                new ArrayList<Target>();

        for (int i = 0;
             i < count;
             i++) {

            targets.add(
                    generateTarget());
        }

        return targets;
    }

    /**
     * Generates a value within the specified interval.
     *
     * @param minimum inclusive lower bound
     * @param maximum exclusive upper bound
     * @return generated value
     */
    private double between(
            double minimum,
            double maximum) {

        return minimum
                + random.nextDouble()
                * (maximum - minimum);
    }
}