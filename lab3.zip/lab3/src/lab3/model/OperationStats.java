package lab3.model;

import java.util.Arrays;

/**
 * Calculates statistics for measured operation times.
 */
public class OperationStats {

    private long[] times;

    /**
     * Creates operation statistics.
     *
     * @param times measured times in nanoseconds
     * @throws IllegalArgumentException if no measurements exist
     */
    public OperationStats(
            long[] times) {

        if (times == null || times.length == 0) {

            throw new IllegalArgumentException(
                    "Measurements are required");
        }

        this.times = times.clone();
    }

    /**
     * Returns the number of measured operations.
     *
     * @return operation count
     */
    public int getCount() {
        return times.length;
    }

    /**
     * Calculates the total operation time.
     *
     * @return total time in nanoseconds
     */
    public long getTotal() {

        long total = 0;

        for (long time : times) {
            total += time;
        }

        return total;
    }

    /**
     * Calculates the arithmetic mean operation time.
     *
     * @return mean time in nanoseconds
     */
    public double getMean() {

        return (double) getTotal()
                / getCount();
    }

    /**
     * Calculates the median operation time.
     *
     * @return median time in nanoseconds
     */
    public double getMedian() {

        long[] sorted =
                times.clone();

        Arrays.sort(sorted);

        int middle =
                sorted.length / 2;

        if (sorted.length % 2 == 1) {
            return sorted[middle];
        }

        return sorted[middle - 1] / 2.0
                + sorted[middle] / 2.0;
    }
}