package lab3.model;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Checks resource feasibility under the original simulation rules.
 * Drones are reused between targets and are not consumed.
 */
public class FeasibilityCheck {

    /**
     * Creates the feasibility checker.
     */
    public FeasibilityCheck() {
    }

    /**
     * Selects the drone type used against a target.
     *
     * @param type target type
     * @return selected drone type
     */
    public static DroneType selectDrone(
            TargetType type) {

        switch (type) {

            case TANK:
            case CONCRETE_SHELTER:
                return DroneType.LONG_RANGE;

            case AIR_DEFENSE_PICKUP:
            case STRIKE_DRONE:
                return DroneType.INTERCEPTOR;

            case SOLDIER:
                return DroneType.SCOUT;

            default:
                return DroneType.MULTIPURPOSE;
        }
    }

    /**
     * Returns the number of drones required for one target.
     *
     * @param type target type
     * @return required drone count
     */
    public static int requiredDrones(
            TargetType type) {

        switch (type) {

            case TANK:
            case CONCRETE_SHELTER:
                return 3;

            case AIR_DEFENSE_PICKUP:
            case EARTH_SHELTER:
            case STRIKE_DRONE:
                return 2;

            default:
                return 1;
        }
    }

    /**
     * Calculates missing drone counts.
     * Uses the maximum requirement per type because
     * the original simulation reuses drones between targets.
     *
     * @param database available drones
     * @param targets targets to process
     * @return missing drone counts by type
     */
    public Map<DroneType, Integer> findMissing(
            DroneDatabase database,
            List<Target> targets) {

        Map<DroneType, Integer> required =
                new EnumMap<DroneType, Integer>(
                        DroneType.class);

        for (Target target : targets) {

            if (!target.isActive()) {
                continue;
            }

            DroneType type =
                    selectDrone(
                            target.getType());

            int count =
                    requiredDrones(
                            target.getType());

            Integer previous =
                    required.get(type);

            if (previous == null
                    || count > previous) {

                required.put(type, count);
            }
        }

        Map<DroneType, Integer> missing =
                new EnumMap<DroneType, Integer>(
                        DroneType.class);

        for (Map.Entry<DroneType, Integer> entry
                : required.entrySet()) {

            int deficit =
                    entry.getValue()
                            - database.count(
                                    entry.getKey());

            if (deficit > 0) {

                missing.put(
                        entry.getKey(),
                        deficit);
            }
        }

        return missing;
    }

    /**
     * Checks whether the current target-processing stage
     * has sufficient drones and active reconnaissance.
     * Does not guarantee base survival over future steps.
     *
     * @param database available drones
     * @param targets targets to process
     * @param scoutActive whether reconnaissance is active
     * @return true if the processing stage is feasible
     */
    public boolean isSolvable(
            DroneDatabase database,
            List<Target> targets,
            boolean scoutActive) {

        return scoutActive
                && findMissing(
                        database,
                        targets).isEmpty();
    }

    /**
     * Adds the missing drones to the database.
     *
     * @param database database to update
     * @param missing calculated drone deficits
     * @param generator random object generator
     */
    public void addMissing(
            DroneDatabase database,
            Map<DroneType, Integer> missing,
            RandomGenerator generator) {

        for (Map.Entry<DroneType, Integer> entry
                : missing.entrySet()) {

            for (int i = 0;
                 i < entry.getValue();
                 i++) {

                Drone drone =
                        generator.generateDrone(
                                database.size() + 1,
                                entry.getKey());

                database.addDrone(drone);
            }
        }
    }
}