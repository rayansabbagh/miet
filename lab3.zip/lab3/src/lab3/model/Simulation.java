package lab3.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Simulates targets, drones and base protection.
 */
public class Simulation {

    private DroneDatabase database;

    private Random random =
            new Random();

    private RandomGenerator generator =
            new RandomGenerator(
                    new Random().nextLong());

    private int baseHealth = 100;

    private boolean scoutActive = true;
    private int scoutLife = 3;
    private int scoutRestart = 0;

    private List<Target> targets =
            new ArrayList<Target>();

    /**
     * Creates a simulation.
     *
     * @param database drone database used in the simulation
     */
    public Simulation(
            DroneDatabase database) {

        this.database = database;
    }

    /**
     * Runs the simulation for the specified number of steps.
     *
     * @param steps maximum number of simulation steps
     * @return simulation messages
     */
    public List<String> run(
            int steps) {

        List<String> log =
                new ArrayList<String>();

        for (int step = 1;
             step <= steps;
             step++) {

            log.add("\nSTEP " + step);

            List<Target> newTargets =
                    generator.generateTargets(
                            5 + random.nextInt(26));

            targets.addAll(newTargets);

            log.add(
                    "New targets: "
                            + newTargets.size());

            for (Target target : targets) {
                target.move();
            }

            updateScout(log);

            if (scoutActive) {

                processTargets(log);

            } else {

                log.add(
                        "Scout information is outdated.");
            }

            attackBase(log);

            targets.removeIf(
                    target -> !target.isActive());

            log.add(
                    "Base health: "
                            + baseHealth);

            if (baseHealth <= 0) {

                log.add(
                        "The drone base was destroyed.");

                break;
            }
        }

        return log;
    }

    /**
     * Updates the scout lifetime and restart countdown.
     *
     * @param log simulation messages
     */
    private void updateScout(
            List<String> log) {

        if (scoutActive) {

            scoutLife--;

            if (scoutLife == 0) {

                scoutActive = false;
                scoutRestart = 2;

                log.add(
                        "Scout was destroyed. "
                                + "New scout is starting.");
            }

        } else {

            scoutRestart--;

            if (scoutRestart == 0) {

                scoutActive = true;

                scoutLife =
                        3 + random.nextInt(3);

                log.add(
                        "New scout started. "
                                + "Information is current.");
            }
        }
    }

    /**
     * Processes active targets using the available drones.
     * Drones are not consumed by this simulation model.
     *
     * @param log simulation messages
     */
    private void processTargets(
            List<String> log) {

        for (Target target : targets) {

            if (!target.isActive()) {
                continue;
            }

            DroneType droneType =
                    FeasibilityCheck.selectDrone(
                            target.getType());

            int required =
                    FeasibilityCheck.requiredDrones(
                            target.getType());

            if (database.count(droneType)
                    >= required) {

                target.deactivate();

                log.add(
                        target.getType()
                                + " defeated by "
                                + required
                                + " "
                                + droneType);

            } else {

                log.add(
                        "Not enough drones for "
                                + target.getType());
            }
        }
    }

    /**
     * Applies damage caused by active targets.
     *
     * @param log simulation messages
     */
    private void attackBase(
            List<String> log) {

        for (Target target : targets) {

            if (!target.isActive()) {
                continue;
            }

            int damage =
                    target.attackDamage();

            if (damage > 0) {

                baseHealth =
                        Math.max(
                                0,
                                baseHealth - damage);

                log.add(
                        target.getType()
                                + " attacked the base: -"
                                + damage);
            }
        }
    }
}