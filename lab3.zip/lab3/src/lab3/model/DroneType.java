package lab3.model;

/**
 * Defines the available drone model types.
 * The declaration order matches the classification scores
 * calculated in the Drone class.
 */
public enum DroneType {

    /** Long-range drone. */
    LONG_RANGE,

    /** Interceptor drone. */
    INTERCEPTOR,

    /** Scout drone. */
    SCOUT,

    /** Cargo drone. */
    CARGO,

    /** Multipurpose drone. */
    MULTIPURPOSE
}