package lab3;

import java.nio.file.Paths;

import lab3.controller.CollectionController;
import lab3.controller.DroneController;
import lab3.controller.ErrMsgLog;

import lab3.model.CollectionExperiment;
import lab3.model.DroneDatabase;

import lab3.view.CollectionView;
import lab3.view.DroneView;

/**
 * Starts the Variant 5 application for laboratories 2 and 3.
 */
public class Variant5 {

    /**
     * Creates the application entry class.
     */
    public Variant5() {
    }

    /**
     * Starts the application in the selected mode.
     *
     * @param args --lab2 for the original application,
     *             --check for the feasibility demonstration,
     *             or no arguments for all Lab 3 experiments
     */
    public static void main(String[] args) {

        ErrMsgLog messages =
                new ErrMsgLog(Paths.get("logs"));

        if (args.length == 1
                && args[0].equals("--lab2")) {

            DroneDatabase model =
                    new DroneDatabase();

            DroneView view =
                    new DroneView();

            DroneController controller =
                    new DroneController(
                            model,
                            view,
                            messages);

            controller.start();

        } else {

            CollectionExperiment model =
                    new CollectionExperiment();

            CollectionView view =
                    new CollectionView();

            CollectionController controller =
                    new CollectionController(
                            model,
                            view,
                            messages);

            if (args.length == 1
                    && args[0].equals("--check")) {

                controller.checkFeasibility();

            } else {

                controller.start();
                controller.checkFeasibility();
            }
        }
    }
}