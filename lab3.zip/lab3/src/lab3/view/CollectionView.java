package lab3.view;

import java.util.List;
import java.util.Locale;

import lab3.model.ExperimentResult;
import lab3.model.OperationStats;

/**
 * Formats and displays collection experiment results.
 */
public class CollectionView {

    /**
     * Creates the collection view.
     */
    public CollectionView() {
    }

    /**
     * Formats one experiment result.
     *
     * @param result experiment result
     * @return formatted result
     */
    public String formatResult(
            ExperimentResult result) {

        OperationStats add =
                result.getAddStats();

        OperationStats remove =
                result.getRemoveStats();

        return String.format(
                Locale.ROOT,
                "%s N=%d"
                        + " | add Total=%d Mean=%.2f Median=%.2f"
                        + " | remove Total=%d Mean=%.2f Median=%.2f ns",
                result.getCollectionName(),
                result.getSize(),
                add.getTotal(),
                add.getMean(),
                add.getMedian(),
                remove.getTotal(),
                remove.getMean(),
                remove.getMedian());
    }

    /**
     * Builds conclusions from the measured results.
     *
     * @param results alternating ArrayList and LinkedList results
     * @return formatted conclusions
     */
    public String conclusions(
            List<ExperimentResult> results) {

        StringBuilder text =
                new StringBuilder();

        text.append("MEASURED RESULTS\n");

        text.append(
                "Mean = arithmetic mean; "
                        + "Median = actual median.\n\n");

        for (int i = 0;
             i + 1 < results.size();
             i += 2) {

            ExperimentResult array =
                    results.get(i);

            ExperimentResult linked =
                    results.get(i + 1);

            text.append(
                    formatResult(array));

            text.append('\n');

            text.append(
                    formatResult(linked));

            text.append('\n');

            text.append("Lower add Total: ");

            text.append(
                    array.getAddStats().getTotal()
                            <= linked.getAddStats().getTotal()
                            ? "ArrayList"
                            : "LinkedList");

            text.append('\n');

            text.append("Lower remove Total: ");

            text.append(
                    array.getRemoveStats().getTotal()
                            <= linked.getRemoveStats().getTotal()
                            ? "ArrayList"
                            : "LinkedList");

            text.append('\n');

            if (i >= 2) {

                appendGrowth(
                        text,
                        array,
                        results.get(i - 2));

                appendGrowth(
                        text,
                        linked,
                        results.get(i - 1));
            }

            text.append('\n');
        }

        text.append(
                "ArrayList: append is amortized O(1); "
                        + "indexed removal is O(n) due to shifts.\n");

        text.append(
                "LinkedList: append is O(1); "
                        + "random indexed removal is O(n) "
                        + "due to node traversal.\n");

        text.append(
                "Total depends on operation count; "
                        + "Mean and Median describe "
                        + "individual operations.\n");

        text.append(
                "Timing depends on JIT, GC and system load. "
                        + "One run does not establish "
                        + "a universal winner.\n");

        text.append(
                "Capacity measurements are recorded "
                        + "in the ArrayList log files.\n");

        return text.toString();
    }

    /**
     * Appends timing changes between consecutive sizes.
     *
     * @param text output text
     * @param current current experiment result
     * @param previous previous experiment result
     */
    private void appendGrowth(
            StringBuilder text,
            ExperimentResult current,
            ExperimentResult previous) {

        text.append(
                String.format(
                        Locale.ROOT,
                        "%s size growth %d -> %d:"
                                + " add Total x%.2f, Median x%.2f;"
                                + " remove Total x%.2f, Median x%.2f%n",
                        current.getCollectionName(),
                        previous.getSize(),
                        current.getSize(),
                        ratio(
                                current.getAddStats().getTotal(),
                                previous.getAddStats().getTotal()),
                        ratio(
                                current.getAddStats().getMedian(),
                                previous.getAddStats().getMedian()),
                        ratio(
                                current.getRemoveStats().getTotal(),
                                previous.getRemoveStats().getTotal()),
                        ratio(
                                current.getRemoveStats().getMedian(),
                                previous.getRemoveStats().getMedian())));
    }

    /**
     * Calculates a timing ratio.
     *
     * @param current current value
     * @param previous previous value
     * @return ratio or NaN if the denominator is zero
     */
    private double ratio(
            double current,
            double previous) {

        return previous == 0
                ? Double.NaN
                : current / previous;
    }

    /**
     * Displays a message in the console.
     *
     * @param text message to display
     */
    public void show(
            String text) {

        System.out.println(text);
    }
}
