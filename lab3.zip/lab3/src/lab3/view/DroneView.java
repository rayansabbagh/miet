package lab3.view;

import java.util.List;
import java.util.Scanner;

import lab3.model.Drone;
import lab3.model.DroneDatabase;
import lab3.model.DroneType;

/**
 * Handles drone input and output in the console.
 */
public class DroneView {

    private Scanner input =
            new Scanner(System.in);

    /**
     * Creates the console view.
     */
    public DroneView() {
    }

    /**
     * Displays information about the drone database.
     *
     * @param database drone database to display
     */
    public void showDatabase(
            DroneDatabase database) {

        System.out.println(
                "Database: "
                        + database.size()
                        + " drones");

        for (DroneType type :
                DroneType.values()) {

            System.out.println(
                    type
                            + ": "
                            + database.count(type));
        }
    }

    /**
     * Reads information about a new drone.
     *
     * @return created drone
     * @throws NumberFormatException if a value is not numeric
     */
    public Drone readDrone() {

        System.out.println(
                "\nADD NEW DRONE");

        System.out.print("Name: ");

        String name =
                input.nextLine();

        String[] names = {
                "Cruise speed",
                "Maximum speed",
                "Fuel range",
                "Control range",
                "Flight time",
                "Drone cost",
                "Preparation cost",
                "Reusable (1/0)",
                "Normal load",
                "Maximum load",
                "Maximum altitude",
                "Preparation time"
        };

        double[] values =
                new double[12];

        for (int i = 0;
             i < values.length;
             i++) {

            System.out.print(
                    names[i] + ": ");

            values[i] =
                    Double.parseDouble(
                            input.nextLine());
        }

        return new Drone(
                name,
                null,
                values);
    }

    /**
     * Displays drone characteristics.
     *
     * @param drone drone to display
     */
    public void showDrone(
            Drone drone) {

        DroneType[] priorities =
                drone.getPriorities();

        System.out.println(
                "Drone: "
                        + drone.getName());

        System.out.println(
                "Priorities: "
                        + priorities[0]
                        + ", "
                        + priorities[1]
                        + ", "
                        + priorities[2]);

        System.out.println(
                "Range at maximum speed/load: "
                        + drone.rangeAtMaximum());

        System.out.println(
                "Time at maximum speed/load: "
                        + drone.timeAtMaximum());

        System.out.println(
                "Technical cost: "
                        + drone.technicalCost());
    }

    /**
     * Displays simulation results.
     *
     * @param lines simulation messages
     */
    public void showSimulation(
            List<String> lines) {

        System.out.println(
                "\nSIMULATION");

        for (String line : lines) {
            System.out.println(line);
        }
    }

    /**
     * Closes the input scanner.
     */
    public void close() {
        input.close();
    }
}