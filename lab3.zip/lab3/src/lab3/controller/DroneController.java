package lab3.controller;

import lab3.model.Drone;
import lab3.model.DroneDatabase;
import lab3.model.Simulation;

import lab3.view.DroneView;

/**
 * Controls communication between the drone model and view.
 */
public class DroneController {

    private DroneDatabase model;
    private DroneView view;
    private ErrMsgLog messages;

    /**
     * Creates the drone controller.
     *
     * @param model drone database
     * @param view console view
     * @param messages centralized message and error handler
     */
    public DroneController(
            DroneDatabase model,
            DroneView view,
            ErrMsgLog messages) {

        this.model = model;
        this.view = view;
        this.messages = messages;
    }

    /**
     * Starts the original drone application.
     * Reads a drone and runs eight simulation steps.
     */
    public void start() {

        try {

            view.showDatabase(model);

            Drone drone =
                    view.readDrone();

            model.addDrone(drone);

            view.showDrone(drone);

            Simulation simulation =
                    new Simulation(model);

            view.showSimulation(
                    simulation.run(8));

        } catch (Exception error) {

            messages.error(error);

        } finally {

            view.close();
        }
    }
}
