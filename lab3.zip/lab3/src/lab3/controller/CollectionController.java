package lab3.controller;

import java.io.BufferedWriter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lab3.model.CollectionExperiment;
import lab3.model.DroneDatabase;
import lab3.model.DroneType;
import lab3.model.ExperimentResult;
import lab3.model.FeasibilityCheck;
import lab3.model.RandomGenerator;
import lab3.model.Target;
import lab3.model.TargetType;

import lab3.view.CollectionView;

/**
 * Controls collection experiments and feasibility demonstrations.
 */
public class CollectionController {

    private CollectionExperiment model;
    private CollectionView view;
    private ErrMsgLog messages;

    /**
     * Creates the collection controller.
     *
     * @param model collection experiment model
     * @param view result view
     * @param messages centralized message and error handler
     */
    public CollectionController(
            CollectionExperiment model,
            CollectionView view,
            ErrMsgLog messages) {

        this.model = model;
        this.view = view;
        this.messages = messages;
    }

    /**
     * Runs ten experiments and saves performance conclusions.
     */
    public void start() {

        List<ExperimentResult> results =
                new ArrayList<ExperimentResult>();

        int[] sizes = {
                10,
                100,
                1000,
                10000,
                100000
        };

        try {

            for (int size : sizes) {

                ExperimentResult array =
                        model.run(
                                true,
                                size,
                                messages);

                results.add(array);

                view.show(
                        view.formatResult(array));

                ExperimentResult linked =
                        model.run(
                                false,
                                size,
                                messages);

                results.add(linked);

                view.show(
                        view.formatResult(linked));
            }

            String conclusions =
                    view.conclusions(results);

            try (BufferedWriter writer =
                         messages.open(
                                 "conclusions.txt")) {

                messages.line(
                        writer,
                        conclusions);
            }

            view.show(conclusions);

        } catch (Exception error) {

            messages.error(error);

        } finally {

            view.show(
                    "Errors in current run: "
                            + messages.getErrorCount());
        }
    }

    /**
     * Demonstrates feasibility checking, resource correction
     * and checking with inactive reconnaissance.
     */
    public void checkFeasibility() {

        try {

            RandomGenerator generator =
                    new RandomGenerator(2026);

            DroneDatabase database =
                    generator.generateDatabase(2);

            List<Target> targets =
                    generator.generateTargets(10);

            /*
             * Include every target type in the demonstration.
             */
            for (TargetType type :
                    TargetType.values()) {

                targets.add(
                        generator.generateTarget(type));
            }

            FeasibilityCheck checker =
                    new FeasibilityCheck();

            StringBuilder report =
                    new StringBuilder();

            report.append(
                    "FEASIBILITY MODE\n");

            report.append(
                    "Checks the target-processing stage "
                            + "under the original simulation rules.\n");

            report.append(
                    "Drones are reused between targets; "
                            + "requirements use a maximum per type.\n");

            report.append(
                    "This does not guarantee base survival "
                            + "through all simulation steps.\n\n");

            report.append(
                    "Generated drones: ");

            report.append(database.size());
            report.append('\n');

            report.append(
                    "Generated targets: ");

            report.append(targets.size());
            report.append('\n');

            Map<DroneType, Integer> missing =
                    checker.findMissing(
                            database,
                            targets);

            report.append(
                    "Initially solvable: ");

            report.append(
                    checker.isSolvable(
                            database,
                            targets,
                            true));

            report.append('\n');

            for (Map.Entry<DroneType, Integer> entry
                    : missing.entrySet()) {

                report.append("Proposal: add ");

                report.append(
                        entry.getValue());

                report.append(
                        " drone(s) of type ");

                report.append(
                        entry.getKey());

                report.append('\n');
            }

            checker.addMissing(
                    database,
                    missing,
                    generator);

            boolean repaired =
                    checker.isSolvable(
                            database,
                            targets,
                            true);

            report.append(
                    "Solvable after adding missing drones: ");

            report.append(repaired);
            report.append('\n');

            if (!repaired) {

                throw new IllegalStateException(
                        "Feasibility correction failed");
            }

            report.append(
                    "Solvable with inactive scout: ");

            report.append(
                    checker.isSolvable(
                            database,
                            targets,
                            false));

            report.append('\n');

            report.append(
                    "With inactive reconnaissance, "
                            + "wait for the scout restart "
                            + "and obtain current target information.\n");

            try (BufferedWriter writer =
                         messages.open(
                                 "feasibility.txt")) {

                messages.line(
                        writer,
                        report.toString());
            }

            view.show(
                    report.toString());

        } catch (Exception error) {

            messages.error(error);
        }
    }
}