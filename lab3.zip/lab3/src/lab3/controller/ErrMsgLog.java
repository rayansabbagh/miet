package lab3.controller;

import java.io.BufferedWriter;
import java.io.IOException;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import lab3.model.OperationStats;

/**
 * Writes log files and centrally handles application errors.
 */
public class ErrMsgLog {

    private int errorCount;
    private Path directory;

    /**
     * Creates the message and error handler.
     *
     * @param directory output directory
     */
    public ErrMsgLog(
            Path directory) {

        this.directory = directory;
    }

    /**
     * Opens a UTF-8 output file.
     * Replaces the previous contents of the file.
     *
     * @param name output file name
     * @return opened writer
     * @throws IOException if the file cannot be opened
     */
    public BufferedWriter open(
            String name) throws IOException {

        Files.createDirectories(directory);

        return Files.newBufferedWriter(
                directory.resolve(name),
                StandardCharsets.UTF_8);
    }

    /**
     * Writes one line to a log file.
     *
     * @param writer output writer
     * @param text line contents
     * @throws IOException if writing fails
     */
    public void line(
            BufferedWriter writer,
            String text) throws IOException {

        writer.write(text);
        writer.newLine();
    }

    /**
     * Writes timing statistics for an operation type.
     *
     * @param writer output writer
     * @param operation operation name
     * @param stats measured operation statistics
     * @throws IOException if writing fails
     */
    public void statistics(
            BufferedWriter writer,
            String operation,
            OperationStats stats) throws IOException {

        line(
                writer,
                operation + "TotalCount = "
                        + stats.getCount());

        line(
                writer,
                operation + "TotalTime = "
                        + stats.getTotal());

        line(
                writer,
                operation + "MeanTime = "
                        + stats.getMean());

        line(
                writer,
                operation + "MedianTime = "
                        + stats.getMedian());
    }

    /**
     * Counts, displays and records an error.
     *
     * @param error caught exception
     */
    public void error(
            Exception error) {

        errorCount++;

        String text =
                now()
                        + " ERROR "
                        + errorCount
                        + ": "
                        + error;

        System.err.println(text);

        try {

            Files.createDirectories(directory);

            Files.writeString(
                    directory.resolve("errors.txt"),
                    text + System.lineSeparator(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);

        } catch (IOException loggingError) {

            errorCount++;

            System.err.println(
                    "Cannot write error log: "
                            + loggingError);
        }
    }

    /**
     * Returns the number of errors in the current run.
     *
     * @return error count
     */
    public int getErrorCount() {
        return errorCount;
    }

    /**
     * Returns the current formatted date and time.
     *
     * @return formatted timestamp
     */
    public String now() {

        return LocalDateTime.now().format(
                DateTimeFormatter.ofPattern(
                        "dd.MM.yyyy HH:mm:ss"));
    }
}
